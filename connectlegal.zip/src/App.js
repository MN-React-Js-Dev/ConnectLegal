import logo from './logo.svg';
import './App.css';
import './assets/css/fontawesome.css'
import './assets/css/templatemo-space-dynamic.css'
import './assets/css/animated.css'
import './assets/css/owl.css'
import './assets/vendor/bootstrap/css/bootstrap.min.css'
import Header from './Component/Navbar/Header';
import Thirdcontainer from './Component/Thirdcontainer';
import Secondcontainer from './Component/SecondContainer';
import Firstcontainer from './Component/FirstContainer';


function App() {
  return (
    <>
      <Firstcontainer />
      <Secondcontainer/>
      <Thirdcontainer/>
    </>
  );
}

export default App;
